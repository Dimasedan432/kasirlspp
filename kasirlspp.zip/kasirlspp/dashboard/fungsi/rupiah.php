<?php
function rupiah($angka)
{
	$hasil_rupiah = number_format($angka);
	return $hasil_rupiah;
}
