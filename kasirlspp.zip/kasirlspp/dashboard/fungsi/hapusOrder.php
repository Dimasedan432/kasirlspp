<?php
session_start();
require  '../../koneksi.php';

$id  = $_GET['id'];
$hapus_user = "DELETE FROM tb_detail_order WHERE id_dorder = '$id'";
$query = mysqli_query($kon, $hapus_user);
if ($query > 0) {
	$_SESSION['pesan'] = '
		<div class="alert alert-success mb-2 alert-dismissible text-small " role="alert">
			laporan telah dihapus
			<button type="button" class="close" data-dismiss="alert" aria-label="close"><span aria-hidden="true">&times;</span></button>
		</div>
	';
	header('location:../index.php?home');
} else {
	$_SESSION['pesan'] = '
		<div class="alert alert-danger mb-2 alert-dismissible text-small " role="alert">
			pesanan gagal dihapus
			<button type="button" class="close" data-dismiss="alert" aria-label="close"><span aria-hidden="true">&times;</span></button>
		</div>
	';
	header('location:../index.php?home');
}
